import math

class RobotArm(Actor):
    def __init__(self):
        self.UpperArm = Container(0)
        self.LowerArm = Container(1)
        self.Hand = Container(2)
        self.Angle = 0
        return
        
    def OnCreate(self, uid):
        self.UTramsform = self.UpperArm.FindComponentByType("TransformGroup")
        self.LTramsform = self.LowerArm.FindComponentByType("TransformGroup")
        self.HTramsform = self.Hand.FindComponentByType("TransformGroup")
        return 0

    def OnDestroy(self):
        return 0

    def OnEnable(self):
        return 0

    def OnDisable(self):
        return 0

    def Update(self):
        return

    def MoveArm(self, x, y, speed):
        Upos = self.UTramsform.GetPosition()
        self.UTramsform.Rotate(x, y, Upos)
        self.Angle = self.Angle - y * speed

        rot = Math3d.Quaternion.EulerDegreeToQuaternionFloat(Math3d.Vector3(self.Angle, 0, 0))
        self.LTramsform.SetLocalRotation(rot)
        self.HTramsform.SetLocalRotation(rot)
        return

    def Reset(self):
        self.UTramsform.SetLocalRotation(Math3d.Vector3(0, 0, 0))
        self.LTramsform.SetLocalRotation(Math3d.Vector3(0, 0, 0))
        self.HTramsform.SetLocalRotation(Math3d.Vector3(0, 0, 0))
        self.Angle = 0
        return
    
    def OnMessage(self, msg, number, Vector4_lparm, Vector4_wparam):
        if (msg == "KeyDown"):
            if(number == 87):   #W
                self.MoveArm(0, 1, 2)
            elif(number == 65): #A
                self.MoveArm(3, 0, 2)
            elif(number == 83): #S
                self.MoveArm(0, -1, 2)
            elif(number == 68): #D
                self.MoveArm(-3, 0, 2)
            elif(number == 82): #R
                self.Reset()
        return