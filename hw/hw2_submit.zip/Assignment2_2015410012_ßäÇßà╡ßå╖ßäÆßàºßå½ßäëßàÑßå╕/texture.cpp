#include "XWindow.h"
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <GL/glut.h>
#include "Bitmap.h"
using namespace std;

//function declaration of this file
void initGL();
void createProgram();
char* ReadFile(char *filename);
GLuint createShader(char* src, GLenum type);
void initLight();
void initTexture();
void initNormal();
void display();
void drawCube(float size);
void drawSquare(float coords[][3], float normals[3]);
void keyPressEvent(char*);;
void ExitProgram();

//function declaration of other file
void ReadOBJ(const char* filename);

//Global variables
GLuint program, vertShader, fragShader = 0;
GLuint idTextureID, nameTextureID;
GLuint idNormalID, nameNormalID;
int shoulder = 0, elbow = 0;
int rotateX = 0, rotateY = 0, rotateZ = 0;

Display                 *dpy;
Window                  root;
GLint                   att[] = { GLX_RGBA, GLX_DEPTH_SIZE, 24, GLX_DOUBLEBUFFER, None };
XVisualInfo             *vi;
Colormap                cmap;
XSetWindowAttributes    swa;
Window                  win;
GLXContext              glc;
XWindowAttributes       gwa;

int main(int argc, char *argv[]) {
	glutInit(&argc, argv);

	/*Initialize Here*/
	dpy = XOpenDisplay(NULL);
	if(dpy == NULL) {
        printf("\n\tcannot connect to X server\n\n");
        exit(0);
	}
	root = DefaultRootWindow(dpy);
	vi = glXChooseVisual(dpy, 0, att);
	if(vi == NULL) {
        printf("\n\tno appropriate visual found\n\n");
        exit(0);
	} else {
        printf("\n\tvisual %p selected\n", (void *)vi->visualid); /* %p creates hexadecimal output like in glxinfo */
	}
	cmap = XCreateColormap(dpy, root, vi->visual, AllocNone);
	swa.colormap = cmap;
	swa.event_mask = KeyPressMask | KeyReleaseMask | ButtonPressMask | ButtonReleaseMask | StructureNotifyMask	;
	win = XCreateWindow(dpy, root, 0, 0, 600, 600, 0, vi->depth, InputOutput, vi->visual, CWColormap | CWEventMask, &swa);
	XMapWindow(dpy, win);
	XStoreName(dpy, win, "Lecture");
	glc = glXCreateContext(dpy, vi, NULL, GL_TRUE);
	glXMakeCurrent(dpy, win, glc);
	glEnable(GL_DEPTH_TEST);
	XEvent xev;

	initGL();
    initLight();
	initTexture();
    initNormal();

	while(1) {
		display();
		XNextEvent(dpy, &xev);
		if(xev.type == KeyPress){
			char *key_string = XKeysymToString(XkbKeycodeToKeysym(dpy, xev.xkey.keycode, 0, 0));
			keyPressEvent(key_string);
		}
	}
}

void initGL() {
	glewInit();
	createProgram();
	glEnable(GL_DEPTH_TEST);
}

void createProgram() {
	char* vert;
	char* frag;
	vert = ReadFile("Vertex.glsl");
	frag = ReadFile("Fragment.glsl");
	printf("%s\n",vert);
	printf("%s\n",frag);

	vertShader = createShader(vert, GL_VERTEX_SHADER);
	fragShader = createShader(frag, GL_FRAGMENT_SHADER);
	GLuint p = glCreateProgram();
	glAttachShader(p, vertShader);
	glAttachShader(p, fragShader);
	glLinkProgram(p);

	program = p;
}

char* ReadFile(char *filename) {
    char *buffer = NULL;
    int string_size, read_size;
    FILE *handler = fopen(filename, "r");

    if (handler) {
        fseek(handler, 0, SEEK_END);
        string_size = ftell(handler);
        rewind(handler);
        buffer = (char*) malloc(sizeof(char) * (string_size + 1));
        read_size = fread(buffer, sizeof(char), string_size, handler);
        buffer[string_size] = '\0';
        if (string_size != read_size) {
            free(buffer);
            buffer = NULL;
        }
        fclose(handler);
    }
    return buffer;
}

GLuint createShader(char* src, GLenum type) {
	GLuint shader;
	shader = glCreateShader(type);
	glShaderSource(shader, 1, &src, NULL);
	glCompileShader(shader);
	return shader;
}

void initLight() {
	float lightKa[4] = {1.0,1.0,1.0,1.0};
	float lightKd[4] = {1.0,1.0,1.0,1.0};
	float lightKs[4] = {1.0,1.0,1.0,1.0};
	float lightPos[4] = {0.0f,0.0,1.0,1.0};

	float matKa[4] = {0.2,0.2,0.1,1.0f};
	float matKd[4] = {0.4,0.3,0.1,1.0f};
	float matKs[4] = {1.0,1.0,1.0,1.0f};
	float matShininess = 50.0f;

	glLightfv(GL_LIGHT0, GL_AMBIENT, lightKa);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, lightKd);
	glLightfv(GL_LIGHT0, GL_SPECULAR, lightKs);
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos);

	glMaterialfv(GL_FRONT, GL_AMBIENT, matKa);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, matKd);
	glMaterialfv(GL_FRONT, GL_SPECULAR, matKs);
	glMaterialfv(GL_FRONT, GL_SHININESS, &matShininess);

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_DEPTH_TEST);
}

void initTexture() {
	glActiveTexture(GL_TEXTURE0);
	glGenTextures(1, &idTextureID);
	glBindTexture(GL_TEXTURE_2D, idTextureID);
	Bitmap idBitmap = Bitmap::bitmapFromFile("textures/id.jpg");
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, idBitmap.width(), idBitmap.height(), 0, GL_RGB, GL_UNSIGNED_BYTE, idBitmap.pixelBuffer());
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glBindTexture(GL_TEXTURE_2D, 0);

	glActiveTexture(GL_TEXTURE0);
	glGenTextures(1, &nameTextureID);
	glBindTexture(GL_TEXTURE_2D, nameTextureID);
	Bitmap nameBitmap = Bitmap::bitmapFromFile("textures/name.jpg");
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, nameBitmap.width(), nameBitmap.height(), 0, GL_RGB, GL_UNSIGNED_BYTE, nameBitmap.pixelBuffer());
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glBindTexture(GL_TEXTURE_2D, 0);
}

void initNormal() {
	glActiveTexture(GL_TEXTURE1);
	glGenTextures(1, &idNormalID);
	glBindTexture(GL_TEXTURE_2D, idNormalID);
	Bitmap idBitmap = Bitmap::bitmapFromFile("textures/id_normal.jpg");
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, idBitmap.width(), idBitmap.height(), 0, GL_RGB, GL_UNSIGNED_BYTE, idBitmap.pixelBuffer());
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glBindTexture(GL_TEXTURE_2D, 0);

	glActiveTexture(GL_TEXTURE1);
	glGenTextures(1, &nameNormalID);
	glBindTexture(GL_TEXTURE_2D, nameNormalID);
	Bitmap nameBitmap = Bitmap::bitmapFromFile("textures/name_normal.jpg");
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, nameBitmap.width(), nameBitmap.height(), 0, GL_RGB, GL_UNSIGNED_BYTE, nameBitmap.pixelBuffer());
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glBindTexture(GL_TEXTURE_2D, 0);
}

void display() {
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
	glUseProgram(program);
    glUniform1i(glGetUniformLocation(program, "tex"), 0);
    glUniform1i(glGetUniformLocation(program, "normal_tex"), 1);

	glMatrixMode (GL_PROJECTION);
	glLoadIdentity();
    gluPerspective(65.0, 1.0, 0.5, 100.0);

	glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glTranslatef(-1.5, 0.0, -5.0);
    glPushMatrix();
        glRotatef(20, 1, 0, 1);

        glPushMatrix();
            glTranslatef(-1.0, 0.0, 0.0);
            glRotatef(shoulder, 0.0, 0.0, 1.0);
            glTranslatef(1.0, 0.0, 0.0);
            glPushMatrix();
                glScalef(2.0, 0.4, 1.0);

				glRotatef(rotateX, 1.0, 0.0, 0.0);
				glRotatef(rotateY, 0.0, 1.0, 0.0);
				glRotatef(rotateZ, 0.0, 0.0, 1.0);

                glActiveTexture(GL_TEXTURE0);
                glBindTexture(GL_TEXTURE_2D, nameTextureID);
                glActiveTexture(GL_TEXTURE1);
                glBindTexture(GL_TEXTURE_2D, nameNormalID);
                drawCube(1.0);
                glutWireCube(1.0);
            glPopMatrix();

            glTranslatef(1.0, 0.0, 0.0);
            glRotatef(elbow, 0.0, 0.0, 1.0);
            glTranslatef(1.0, 0.0, 0.0);

            glPushMatrix();
                glScalef(2.0, 0.4, 1.0);
                glActiveTexture(GL_TEXTURE0);
                glBindTexture(GL_TEXTURE_2D, idTextureID);
                glActiveTexture(GL_TEXTURE1);
                glBindTexture(GL_TEXTURE_2D, idNormalID);
                drawCube(1.0);
                glutWireCube(1.0);
            glPopMatrix();
        glPopMatrix();
    glPopMatrix();

	glUseProgram(0);
	glXSwapBuffers(dpy, win);
}

void drawCube(float s) {
    float size = 0.5 * s;

    GLfloat normals[6][3] = {
        {-1.0,  0.0,  0.0},
        { 0.0,  1.0,  0.0},
        { 1.0,  0.0,  0.0},
        { 0.0, -1.0,  0.0},
        { 0.0,  0.0, -1.0},
        { 0.0,  0.0,  1.0}
    };

    float coords1[][3] = {
        {-size,  size, -size},
        {-size,  size,  size},
        {-size, -size,  size},
        {-size, -size, -size}
    };

    float coords2[][3] = {
    	{-size,  size, -size},
        { size,  size, -size},
    	{ size,  size,  size},
    	{-size,  size,  size}
    };

    float coords3[][3] = {
    	{ size,  size,  size},
        { size,  size, -size},
    	{ size, -size, -size},
    	{ size, -size,  size}
    };

    float coords4[][3] = {
    	{-size, -size,  size},
        { size, -size,  size},
    	{ size, -size, -size},
    	{-size, -size, -size}
    };

    float coords5[][3] = {
    	{ size,  size, -size},
        {-size,  size, -size},
    	{-size, -size, -size},
    	{ size, -size, -size}
    };

    float coords6[][3] = {
        {-size,  size,  size},
        { size,  size,  size},
        { size, -size,  size},
        {-size, -size,  size}
    };

    drawSquare(coords1, normals[0]);
    drawSquare(coords2, normals[1]);
    drawSquare(coords3, normals[2]);
    drawSquare(coords4, normals[3]);
    drawSquare(coords5, normals[4]);
    drawSquare(coords6, normals[5]);
}

void drawSquare(float coords[][3], float normals[3]) {
	glBegin(GL_QUADS);
	glNormal3fv(&normals[0]);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3fv(&coords[0][0]);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3fv(&coords[1][0]);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3fv(&coords[2][0]);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3fv(&coords[3][0]);
	glEnd();
}

void keyPressEvent(char* key_string) {
	if(strncmp(key_string, "Up", 2) == 0) {
		shoulder = (shoulder + 5) % 360;
	} else if(strncmp(key_string, "Down", 4) == 0) {
		shoulder = (shoulder - 5) % 360;
	} else if(strncmp(key_string, "Right", 5) == 0) {
		elbow = (elbow + 5) % 360;
	} else if(strncmp(key_string, "Left", 4) == 0) {
		elbow = (elbow - 5) % 360;
	}

	if(strncmp(key_string, "w", 1) == 0) {
		rotateX = (rotateX + 5) % 360;
	} else if(strncmp(key_string, "s", 1) == 0) {
		rotateX = (rotateX - 5) % 360;
	} else if(strncmp(key_string, "a", 1) == 0) {
		rotateY = (rotateY + 5) % 360;
	} else if(strncmp(key_string, "d", 1) == 0) {
		rotateY = (rotateY - 5) % 360;
	} else if(strncmp(key_string, "q", 1) == 0) {
		rotateZ = (rotateZ + 5) % 360;
	} else if(strncmp(key_string, "e", 1) == 0) {
		rotateZ = (rotateZ - 5) % 360;
	}

	if(strncmp(key_string, "Escape", 6) == 0) {
        ExitProgram();
    }
}

void ExitProgram() {
	glXMakeCurrent(dpy, None, NULL);
	glXDestroyContext(dpy, glc);
	XDestroyWindow(dpy, win);
	XCloseDisplay(dpy);
}
